
from matplotlib import pyplot as plt
import pandas as pd
import seaborn as sns


# Importiamo il file immigrati "immigrants_by_nationality.csv"

immigrati_per_nazionalita = pd.read_csv("immigrants_by_nationality.csv")
#print(immigrati_per_nazionalita)


# 1: Distribuzione temporale dell'immigrazione negli anni

distribuzione_temporale = immigrati_per_nazionalita.groupby("Year")["Number"].sum()
#print(distribuzione_temporale)
distribuzione_temporale.plot(kind= 'barh', color='green')
plt.title('Distribuzione Temporale Immigrazione Negli Anni')
plt.xlabel('Numero di Immigrati')
plt.ylabel('Anno')
plt.show()





# 2: Quali sono le nazionalità più comuni tra gli immigrati?

nazionalità_comuni = immigrati_per_nazionalita.groupby("Nationality")["Number"].sum().sort_values(ascending=False)
plt.figure(figsize=(10,5))
sns.barplot(x=nazionalità_comuni.index[:10], y=nazionalità_comuni.values[:10])  # Solo le prime 10 nazionalità
plt.title("Le 10 nazionalità più comuni tra gli immigrati")
plt.xticks(rotation=90)
plt.show()



# 2.1 : Approfonfimento: Flusso di immigrazione raggruppato per anno e nazionalità

flusso_immigrazione = immigrati_per_nazionalita.groupby(["Year", "Nationality"])["Number"].sum().sort_values(ascending=False)

# Creazione della griglia di subplots
fig, axs = plt.subplots(3, 1, figsize=(10, 15), sharex=True)

# Ciclo per disegnare i grafici per ciascun anno nei subplots
for i, anno in enumerate([2015, 2016, 2017]):
    flusso_anno = flusso_immigrazione.loc[anno].head(10)
    axs[i].bar(flusso_anno.index, flusso_anno.values, label=f'Anno {anno}', color=f'C{i}')

    axs[i].set_title(f"Flusso nell'anno {anno}")
    axs[i].set_xlabel('Nationalità')
    axs[i].set_ylabel('Numero di Immigrati')

# Aggiungi una legenda generale
fig.legend(loc='upper right', bbox_to_anchor=(0.85, 0.9))

# Aggiungi titolo e mostra il grafico
fig.suptitle("Flusso di immigrazione per anno e nazionalità (Top 10)", fontsize=16)
plt.show()





# 3: Quali distretti hanno ricevuto il maggior numero di immigrati?

somma_distretti = immigrati_per_nazionalita.groupby("District Name")["Number"].sum()
#print(somma_distretti)
plt.figure(figsize=(10, 10))
somma_distretti.plot(kind='pie', autopct='%1.2f%%', colors=sns.color_palette('pastel'))
plt.title('Distribuzione del Numero di Immigrati per Distretto')
plt.ylabel('')
plt.show()












