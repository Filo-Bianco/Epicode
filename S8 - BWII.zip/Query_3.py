
from matplotlib import pyplot as plt
import pandas as pd




#    1. CARICAMENTO E PULIZIA DATASET    -    COMUNI


# -    REGIONI    -    Carichiamo il file CSV in un DataFrame
regioni = pd.read_csv('covid19_italy_region _python.csv')
#print(regioni)

# Elimina la seconda colonna, che è uguale alla prima indicizzata
regioni = regioni.drop(['SNo'],axis=1)

# Rimuoviamo righe duplicate - se ci sono
regioni = regioni.drop_duplicates()

# Rimuoviamo righe che contengono valori mancanti (NaN)
regioni= regioni.dropna(how='all')

# Converti la colonna "Date" in formato data e ordina il dataframe per data
regioni['Date'] = pd.to_datetime(regioni['Date']).dt.date
regioni = regioni.sort_values(by=['Date'])

# Sostituisce i valori nulli con zero
regioni = regioni.fillna(0)

# Converti la colonna "TestsPerformed" da float a int
regioni['TestsPerformed'] = regioni['TestsPerformed'].astype(int)
#print(regioni)





#    2. ANALISI


'''
3: Distribuzione stagionale dei casi COVID-19
'''


# 3. Assegnazione dei casi positivi totali a ciascun tipo di terapia
df_regioni = pd.DataFrame(regioni)
df_regioni['Date'] = pd.to_datetime(df_regioni['Date'])
df_regioni.set_index('Date', inplace=True)
# Calcolo dei totali
OspedalizzatiTotITA = df_regioni["HospitalizedPatients"].sum()
TerapiaIntensivaTotITA = df_regioni["IntensiveCarePatients"].sum()
ConfinatiACasaTotITA = df_regioni["HomeConfinement"].sum()
# Calcolo dei totali stagionali
OspedalizzatiStagionaliITA = df_regioni.resample("Q")["HospitalizedPatients"].mean()
TerapiaIntensivaStagionaliITA = df_regioni.resample("Q")["IntensiveCarePatients"].mean()
ConfinatiACasaStagionaliITA = df_regioni.resample("Q")["HomeConfinement"].mean()

# Creazione di un DataFrame per i totali
PazientiPositivi = pd.DataFrame({
    'Ospedalizzati': [OspedalizzatiTotITA],
    'TerapiaIntensiva': [TerapiaIntensivaTotITA],
    'Isolamento domiciliare': [ConfinatiACasaTotITA]
}, index=['Total'])
# Creazione di un DataFrame per i totali stagionali
PazientiPositiviStagionali = pd.DataFrame({
    'Ospedalizzati': OspedalizzatiStagionaliITA,
    'Terapia Intensiva': TerapiaIntensivaStagionaliITA,
    'Isolamento domiciliare': ConfinatiACasaStagionaliITA
})
# Grafico a torta corrispondente
fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2)
fig.suptitle('Distribuzione Stagionale dei Casi COVID-19', fontsize=16, fontweight='bold')



def annotate_pie(ax, labels, sizes):
    ax.pie(sizes, labels=labels, explode =(0.1, 0.2, 0.1), autopct='%1.1f%%', startangle=140, colors=['lightblue', 'lightcoral', 'lightgreen'])
   

annotate_pie(ax1, PazientiPositiviStagionali.columns, PazientiPositiviStagionali.iloc[0])
ax1.set_title('Trimestre Invernale')
annotate_pie(ax2, PazientiPositiviStagionali.columns, PazientiPositiviStagionali.iloc[1])
ax2.set_title('Trimestre Primaverile')
annotate_pie(ax3, PazientiPositiviStagionali.columns, PazientiPositiviStagionali.iloc[2])
ax3.set_title('Trimestre Estivo')
annotate_pie(ax4, PazientiPositiviStagionali.columns, PazientiPositiviStagionali.iloc[3])
ax4.set_title('Trimestre Autunnale')

fig.legend(labels=PazientiPositiviStagionali.columns, loc='upper right')
plt.tight_layout()
plt.show()







