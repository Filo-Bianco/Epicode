
from matplotlib import pyplot as plt
import pandas as pd




#    1. CARICAMENTO E PULIZIA DATASET


# -    REGIONI    -    Carichiamo il file CSV in un DataFrame
regioni = pd.read_csv('covid19_italy_region _python.csv')
#print(regioni)

# Elimina la seconda colonna, che è uguale alla prima indicizzata
regioni = regioni.drop(['SNo'],axis=1)

# Rimuoviamo righe duplicate - se ci sono
regioni = regioni.drop_duplicates()

# Rimuoviamo righe che contengono valori mancanti (NaN)
regioni= regioni.dropna(how='all')

# Converti la colonna "Date" in formato data e ordina il dataframe per data
regioni['Date'] = pd.to_datetime(regioni['Date']).dt.date
regioni = regioni.sort_values(by=['Date'])

# Sostituisce i valori nulli con zero
regioni = regioni.fillna(0)

# Converti la colonna "TestsPerformed" da float a int
regioni['TestsPerformed'] = regioni['TestsPerformed'].astype(int)
#print(regioni)





#    2. ANALISI

'''
1: Totale dei deceduti e dei guariti per ogni regione.
'''

####### 1. Guariti e Deceduti per ogni regione:
# Filtra il DataFrame per la data '2020-12-06'
regioni['Date'] = pd.to_datetime(regioni['Date'])
df_selected_date = regioni[regioni['Date'] == '2020-12-06']
# Raggruppa per regione e calcola il totale dei decessi e dei guariti
group_by_region=df_selected_date.groupby("RegionName").agg({"Deaths":"sum","Recovered":"sum"}).reset_index()
#print(group_by_region[["RegionName","Deaths","Recovered"]])
# Ordina i dati per numero totale di morti in ordine decrescente
group_by_region = group_by_region.sort_values(by='Deaths', ascending=False)
# Plot dei morti e guariti per regione
plt.figure(figsize=(14, 8))  # Aumento delle dimensioni del grafico
bar_height = 0.35
index = range(len(group_by_region['RegionName']))
bars1 = plt.barh(index, group_by_region['Deaths'], bar_height, label='Morti')
bars2 = plt.barh([i + bar_height for i in index], group_by_region['Recovered'], bar_height, label='Guariti')
plt.ylabel('Regione')
plt.xlabel('Indice')
plt.title('Il totale dei Guariti e Deceduti per ogni regione')
# Inverti l'ordine degli elementi sull'asse y
plt.gca().invert_yaxis()
plt.yticks([i + bar_height / 2 for i in index], group_by_region['RegionName'])
plt.legend(loc='lower right')
plt.show()









'''
2:  La distribuzione percentuale di pazienti ospedalizzati, in terapia intensiva e 
    in isolamento domiciliare rispetto al totale dei casi positivi, 
    basate sui dati relativi all'ultima data disponibile da noi scelta ( 6 dicembre 2020).
'''

# Filtra i dati per la data '2020-12-06'
regioni['Date'] = pd.to_datetime(regioni['Date'])
df_selected_date = regioni[regioni['Date'] == '2020-12-06']

# Aggrega i dati per ottenere il totale di ogni categoria
df_selected = df_selected_date[['HospitalizedPatients', 'IntensiveCarePatients', 'HomeConfinement']]
totals = df_selected.sum()

# Grafico a torta corrispondente
labels = ['Ricoverati', 'Terapia intensiva', 'Isolamento']
sizes = totals.values
colors = ['lightblue', 'lightcoral', 'lightgreen', ]
# Definisci il vettore di esplosione
explode = (0.4, 0.6, 0)

plt.figure(figsize=(8, 6))
plt.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%', startangle=140, colors=colors, shadow=True)
plt.axis('equal')  # Garantisce che il grafico a torta sia disegnato come un cerchio
plt.title('Distribuzione dei Casi COVID-19')
plt.show()


