
from matplotlib import pyplot as plt
import pandas as pd



#    1. CARICAMENTO E PULIZIA DATASET


# -    REGIONI    -    Carichiamo il file CSV in un DataFrame
regioni = pd.read_csv('covid19_italy_region _python.csv')
#print(regioni)

# Elimina la seconda colonna, che è uguale alla prima indicizzata
regioni = regioni.drop(['SNo'],axis=1)

# Rimuoviamo righe duplicate - se ci sono
regioni = regioni.drop_duplicates()

# Rimuoviamo righe che contengono valori mancanti (NaN)
regioni= regioni.dropna(how='all')

# Converti la colonna "Date" in formato data e ordina il dataframe per data
regioni['Date'] = pd.to_datetime(regioni['Date']).dt.date
regioni = regioni.sort_values(by=['Date'])

# Sostituisce i valori nulli con zero
regioni = regioni.fillna(0)

# Converti la colonna "TestsPerformed" da float a int
regioni['TestsPerformed'] = regioni['TestsPerformed'].astype(int)
#print(regioni)




# -    POPOLAZIONE    -    Carichiamo il file EXCEL in un DataFrame
popolazione = pd.read_excel('Popolazione2020.xlsx',
                            skiprows=8,
                            names=["Regioni", "Maschi", "Femmine", "Totale"],
                            usecols=[0, 2, 3, 4]).iloc[:-1]

#print(popolazione)

# Converti le colonne da float a int
popolazione[['Maschi', 'Femmine', 'Totale']] = popolazione[['Maschi', 'Femmine', 'Totale']].astype(int)

#print(popolazione)







#    2. ANALISI

'''
0: Stampo i dati sommari di tutto il file regioni
'''

print(regioni.describe())

'''
Per salvare i dati di describe in un nuovo file
regioni.describe().to_csv("describe.csv")
'''





'''
0: Calcolo il totale della popolazione italiana divisa per sesso
'''

totale_popolazione = popolazione["Totale"].sum()
totale_maschi = popolazione["Maschi"].sum()
totale_femmine = popolazione["Femmine"].sum()

print("Il totale della popolazione italiana all'inizio del 2020 è: ", totale_popolazione)
print("Il totale della popolazione italiana maschile è: ", totale_maschi)
print("Il totale della popolazione italiana femminile è: ", totale_femmine)


# Creazione di un grafico a torta
plt.figure(figsize=(8, 8))
sizes = [totale_maschi, totale_femmine]
labels = ['Maschi', 'Femmine']
colors = ['lightblue', 'pink']
explode = (0.1, 0)  # Esplosione della fetta 'Maschi'

plt.pie(sizes, labels=labels, colors=colors, explode=explode, autopct='%1.1f%%', shadow=True, startangle=140)
plt.title('Totale della popolazione italiana per sesso (2020)', fontsize=16)
plt.axis('equal')  # Equalizza gli assi per rendere il grafico a torta circolare

total_text = f'Totale \n popolazione: \n {totale_popolazione}'
plt.figtext(0.9, 0.5, total_text, ha='center', va='center', fontsize=12, color='black')

plt.show()






