
from matplotlib import pyplot as plt
import pandas as pd
import seaborn as sns

# Importiamo il file "immigrants_by_age.csv"
immigrati_per_eta= pd.read_csv("immigrants_by_age.csv")
#print(immigrati_per_eta)


# 1: Totale degli Immigrati e Emigrati suddivisi per fascia d'età

# Flusso di immigrazione per fascia d'età
imm_per_eta = immigrati_per_eta.groupby("Age")["Immigrants"].sum().sort_index(ascending=False)
#print(imm_per_eta)
imm_per_eta.plot(kind= 'barh', color='blue')
plt.title("Totale Immigrazione per fascia d'eta")
plt.xlabel('Numero di Immigrati')
plt.ylabel("Fascia d'eta")
plt.show()

# Flusso di emigrazione per fascia d'età
emi_per_eta = immigrati_per_eta.groupby("Age")["Emigrants"].sum().sort_index(ascending=False)
#print(emi_per_eta)
emi_per_eta.plot(kind= 'barh', color='orange')
plt.title("Totale Emigrati per fascia d'eta")
plt.xlabel('Numero di Emigrati')
plt.ylabel("Fascia d'eta")
plt.show()




'''
    Oppure usando subplots posso mostrare i due grafici insieme

# Flusso di immigrazione per fascia d'età
imm_per_eta = immigrati_per_eta.groupby("Age")["Immigrants"].sum().sort_index(ascending=False)

# Flusso di emigrazione per fascia d'età
emi_per_eta = immigrati_per_eta.groupby("Age")["Emigrants"].sum().sort_index(ascending=False)

# Creazione della figura con due subplot (1 riga, 2 colonne)
fig, axs = plt.subplots(1, 2, figsize=(12, 6))

# Grafico a barre per l'immigrazione
axs[0].barh(imm_per_eta.index, imm_per_eta.values, color='blue')
axs[0].set_title("Totale Immigrazione per fascia d'eta")
axs[0].set_xlabel('Numero di Immigrati')
axs[0].set_ylabel("Fascia d'eta")

# Grafico a barre per l'emigrazione
axs[1].barh(emi_per_eta.index, emi_per_eta.values, color='orange')
axs[1].set_title("Totale Emigrati per fascia d'eta")
axs[1].set_xlabel('Numero di Emigrati')
axs[1].set_ylabel("Fascia d'eta")

# Mostra il grafico
plt.show()

'''





# Importiamo il file "immigrants_by_sex.csv"
immigrati_per_sesso= pd.read_csv("immigrants_by_sex.csv")
#print(immigrati_per_sesso)


# 2: Totale degli Immigrati e Emigrati suddivisi per sesso

# Flusso di immigrazione per sesso
imm_per_sesso = immigrati_per_sesso.groupby("Gender")["Immigrants"].sum().sort_index(ascending=False)
#print(imm_per_sesso)
plt.figure(figsize=(10, 10))
imm_per_sesso.plot(kind='pie', autopct='%1.2f%%')
plt.title('Numero di Immigrati per sesso')
plt.ylabel('')
plt.show()

# Flusso di emigrazione per sesso
emi_per_sesso = immigrati_per_sesso.groupby("Gender")["Emigrants"].sum().sort_index(ascending=False)
#print(emi_per_sesso)
plt.figure(figsize=(10, 10))
emi_per_sesso.plot(kind='pie', autopct='%1.2f%%', startangle=90, colors=('cyan','magenta'))
plt.title('Numero di Emigrati per sesso')
plt.ylabel('')
plt.show()






# Importiamo il file "unemployment.csv"
unemployment = pd.read_csv("unemployment.csv")
#print(unemployment)


# 3: Qual è la richiesta di lavoro per distretto?

total = unemployment["Number"].sum()
unemployment["Percentage"] = unemployment["Number"] / total * 100
richiesta_lavoro_per_disretto = unemployment.groupby("District Name")["Number"].sum().sort_values(ascending=False)
plt.figure(figsize=(10,5))
sns.barplot(x=richiesta_lavoro_per_disretto.index, y=richiesta_lavoro_per_disretto.values)
plt.title("Richiesta lavoro per distretto")
plt.xticks(rotation=90)
plt.show()


# 4: Qual è la richiesta di lavoro per sesso?
richiesta_per_genere = unemployment.groupby("Gender")["Number"].sum()
plt.figure(figsize=(10,5))
richiesta_per_genere.plot(kind='pie', autopct='%1.2f%%', startangle=90, colors=('cyan','magenta'))
plt.title("Richiesta lavoro per genere")
plt.ylabel('')
plt.show()


