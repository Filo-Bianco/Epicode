
from matplotlib import pyplot as plt
import pandas as pd
import seaborn as sns




#    1. CARICAMENTO E PULIZIA DATASET    -    COMUNI


# -    PROVINCE    -    Carichiamo il file CSV in un DataFrame
province = pd.read_csv('covid19_italy_province _python.csv')
#print(province)

# Elimina la seconda colonna, che è uguale alla prima indicizzata
province = province.drop(['SNo'],axis=1)

# Rimuoviamo righe duplicate - se ci sono
province = province.drop_duplicates()

# Rimuoviamo righe che contengono valori mancanti (NaN)
province= province.dropna(how='all')

# Converti la colonna "Date" in formato data e ordina il dataframe per data
province['Date'] = pd.to_datetime(province['Date']).dt.date
province = province.sort_values(by=['Date'])

# Converti la colonna "TotalPositiveCases" da float a int
province['TotalPositiveCases'] = province['TotalPositiveCases'].astype(int)
#print(province)




# -    REGIONI    -    Carichiamo il file CSV in un DataFrame
regioni = pd.read_csv('covid19_italy_region _python.csv')
#print(regioni)

# Elimina la seconda colonna, che è uguale alla prima indicizzata
regioni = regioni.drop(['SNo'],axis=1)

# Rimuoviamo righe duplicate - se ci sono
regioni = regioni.drop_duplicates()

# Rimuoviamo righe che contengono valori mancanti (NaN)
regioni= regioni.dropna(how='all')

# Converti la colonna "Date" in formato data e ordina il dataframe per data
regioni['Date'] = pd.to_datetime(regioni['Date']).dt.date
regioni = regioni.sort_values(by=['Date'])

# Sostituisce i valori nulli con zero
regioni = regioni.fillna(0)

# Converti la colonna "TestsPerformed" da float a int
regioni['TestsPerformed'] = regioni['TestsPerformed'].astype(int)
#print(regioni)





#    2. ANALISI


'''
4: Andamento mensile dei nuovi casi positivi.
'''

sns.set(style="whitegrid")
plt.figure(figsize=(12, 6))
regioni.groupby('Date')['NewPositiveCases'].sum().plot(marker='.', linestyle='-', color='b', label='Nuovi Casi Positivi')
plt.title('Andamento dei Nuovi Casi Positivi', fontsize=16)
plt.xlabel('Data', fontsize=12)
plt.ylabel('Nuovi Casi Positivi', fontsize=12)
plt.legend()
plt.xticks(rotation=45)
plt.grid(True)
plt.show()




'''
5: Calcola il tasso di guarigione  e il tasso di mortalità nel tempo
'''

# Calcola il tasso di guarigione nel tempo
regioni['RecoveryRate'] = regioni['Recovered'] / regioni['TotalPositiveCases']
recovery_rate = regioni.groupby('Date')['RecoveryRate'].mean()
# Calcola il tasso di mortalità nel tempo
regioni['MortalityRate'] = regioni['Deaths'] / regioni['TotalPositiveCases']
mortality_rate = regioni.groupby('Date')['MortalityRate'].mean()
# Crea il grafico
plt.figure(figsize=(10, 6))
# Barre per il tasso di guarigione
plt.bar(recovery_rate.index, recovery_rate, label='Tasso di guarigione', color='lightgreen')
# Barre per il tasso di mortalità
plt.bar(mortality_rate.index, mortality_rate, label='Tasso di mortalità', color='salmon')
# Titolo e etichette degli assi
plt.title('Tasso di guarigione e tasso di mortalità nel tempo')
plt.xlabel('Data')
plt.ylabel('Tasso')
# Aggiungi una legenda
plt.legend()
# Ruota le etichette sull'asse x per una migliore leggibilità
plt.xticks(rotation=45)
# Mostra il grafico
plt.tight_layout()
plt.show()









'''
6: Le prime 15 province con più positivi

'''

# Filtra il DataFrame per la data '2020-12-06'
province['Date'] = pd.to_datetime(province['Date'])
province_selected_date = province[province['Date'] == '2020-12-06']

# Raggruppa i dati per ProvinceName e calcola la somma dei TotalPositiveCases per ciascuna provincia
province_cases = province_selected_date.groupby('ProvinceName')['TotalPositiveCases'].sum()

# Seleziona le prime 15 province con il numero più alto di casi positivi
# Ordina le province in base al numero totale di casi positivi in ordine decrescente
top_15_province = province_cases.sort_values(ascending=False).head(15)

# Crea il grafico
plt.figure(figsize=(10, 6))
# Plot delle prime 10 regioni con il numero più alto di casi positivi
top_15_province.plot(kind='bar', color='skyblue')
# Titolo e etichette degli assi
plt.title('Top 15 Province con il numero più alto di casi positivi')
plt.xlabel('Province')
plt.ylabel('Totale casi positivi')
# Mostra il grafico
plt.xticks(rotation=90)  # Ruota le etichette sull'asse x per una migliore leggibilità
plt.tight_layout()
plt.show()











