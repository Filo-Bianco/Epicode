
from matplotlib import pyplot as plt
import pandas as pd
import seaborn as sns




#    1. CARICAMENTO E PULIZIA DATASET    -    COMUNI


# -    PROVINCE    -    Carichiamo il file CSV in un DataFrame
province = pd.read_csv('covid19_italy_province _python.csv')
#print(province)

# Elimina la seconda colonna, che è uguale alla prima indicizzata
province = province.drop(['SNo'],axis=1)

# Rimuoviamo righe duplicate - se ci sono
province = province.drop_duplicates()

# Rimuoviamo righe che contengono valori mancanti (NaN)
province= province.dropna(how='all')

# Converti la colonna "Date" in formato data e ordina il dataframe per data
province['Date'] = pd.to_datetime(province['Date']).dt.date
province = province.sort_values(by=['Date'])

# Converti la colonna "TotalPositiveCases" da float a int
province['TotalPositiveCases'] = province['TotalPositiveCases'].astype(int)
#print(province)




# -    REGIONI    -    Carichiamo il file CSV in un DataFrame
regioni = pd.read_csv('covid19_italy_region _python.csv')
#print(regioni)

# Elimina la seconda colonna, che è uguale alla prima indicizzata
regioni = regioni.drop(['SNo'],axis=1)

# Rimuoviamo righe duplicate - se ci sono
regioni = regioni.drop_duplicates()

# Rimuoviamo righe che contengono valori mancanti (NaN)
regioni= regioni.dropna(how='all')

# Converti la colonna "Date" in formato data e ordina il dataframe per data
regioni['Date'] = pd.to_datetime(regioni['Date']).dt.date
regioni = regioni.sort_values(by=['Date'])

# Sostituisce i valori nulli con zero
regioni = regioni.fillna(0)

# Converti la colonna "TestsPerformed" da float a int
regioni['TestsPerformed'] = regioni['TestsPerformed'].astype(int)
#print(regioni)





#    2. ANALISI


'''
7: Variazione dei nuovi casi per la regione Lombardia
'''

lombardia_data = regioni[regioni['RegionName'] == 'Lombardia']
lombardia_data['Date'] = pd.to_datetime(lombardia_data['Date'])

weekly_new_cases = lombardia_data.groupby(pd.Grouper(key='Date', freq='W-Mon'))['NewPositiveCases'].sum().reset_index()
# Grafico corrispondente
plt.figure(figsize=(12, 8))
plt.plot(weekly_new_cases['Date'], weekly_new_cases['NewPositiveCases'], marker='o', markersize=5, label='Nuovi casi settimanali')
plt.title('Variazioni Settimanali dei Nuovi Casi nella Regione Lombardia')
plt.xlabel('Data')
plt.ylabel('Nuovi casi')
plt.xticks(rotation=45)
plt.grid(True)
plt.legend()
plt.tight_layout()

# Aggiungi annotazioni, ad esempio la data con il picco massimo di nuovi casi
peak_date = weekly_new_cases.loc[weekly_new_cases['NewPositiveCases'].idxmax(), 'Date']
peak_cases = weekly_new_cases['NewPositiveCases'].max()
plt.annotate(f'Picco: {peak_cases} casi\n{peak_date.strftime("%d-%m-%Y")}',
             xy=(peak_date, peak_cases), xytext=(peak_date, peak_cases + 100),
             arrowprops=dict(facecolor='red', arrowstyle='->'),
             fontsize=10, color='red')
plt.show()




'''
8: Variazione dei nuovi casi per le province della regione Lombardia
'''

# Filtra i dati solo per la regione Lombardia
lombardia_data = province[province['RegionName'] == 'Lombardia']

# Rimuovi le righe in cui ProvinceCode è uguale a 988 o 888
lombardia_data = lombardia_data.loc[~((lombardia_data['ProvinceCode'] == 988) | (lombardia_data['ProvinceCode'] == 888))]

# Resetta l'indice dopo la rimozione delle righe
lombardia_data = lombardia_data.reset_index(drop=True)

# Converte la colonna 'Date' in formato datetime
lombardia_data['Date'] = pd.to_datetime(lombardia_data['Date'])

# Raggruppa i dati per provincia e settimana, calcolando la somma dei nuovi casi per ogni settimana
weekly_new_cases_by_province = lombardia_data.groupby(['ProvinceName', pd.Grouper(key='Date', freq='W-Mon')])['TotalPositiveCases'].sum().reset_index()

# Crea un grafico per visualizzare le variazioni settimanali dei nuovi casi per ogni provincia
plt.figure(figsize=(12, 8))

# Itera attraverso le province e traccia i dati
for province, data in weekly_new_cases_by_province.groupby('ProvinceName'):
    plt.plot(data['Date'], data['TotalPositiveCases'], label=province, marker='o', markersize=5)

# Aggiungi la legenda, titolo e etichette degli assi
plt.legend()
plt.title('Variazioni settimanali dei nuovi casi per provincia nella regione Lombardia')
plt.xlabel('Settimana')
plt.ylabel('Nuovi casi')
plt.xticks(rotation=45)
plt.grid(True)
plt.tight_layout()
plt.show()






'''
9: Calcolare la percentuale di morti rispetto al totale dei casi positivi complessivo
'''

# Filtra il DataFrame per la data '2020-12-06'
regioni['Date'] = pd.to_datetime(regioni['Date'])
df_selected_date = regioni[regioni['Date'] == '2020-12-06']

total_death_percentage = (df_selected_date['Deaths'].sum() / df_selected_date['TotalPositiveCases'].sum()) * 100
#print(f'La percentuale totale di morti rispetto al totale dei casi positivi è: {total_death_percentage:.2f}%')

# Crea un DataFrame con i valori per il grafico a torta
data = {'Morti': total_death_percentage, 'Guariti': 100 - total_death_percentage}
df = pd.DataFrame(data, index=['Percentuale'])

# Crea il grafico a torta
plt.figure(figsize=(8, 8))
colors = ['lightcoral', 'lightgreen']
explode = (0.3, 0)  # Evidenzia il segmento relativo ai decessi
plt.pie(df.iloc[0], labels=df.columns, autopct='%1.1f%%', colors=colors, explode=explode, shadow=True, startangle=140)
plt.title('Percentuale totale di morti rispetto al totale dei casi positivi', fontsize=16)
plt.axis('equal')  # Garantisce che il grafico sia circolare
plt.show()





'''
10: Verificare la correlazione tra Test effettuati', 'Nuovi casi positivi', 'Pazienti ospedalizzati', 'Guariti', 'Decessi'
'''
# Seleziona le colonne necessarie
data_for_correlation = regioni[['TestsPerformed', 'NewPositiveCases', 'HospitalizedPatients', 'Recovered', 'Deaths']]

# Calcola la matrice di correlazione
correlation_matrix = data_for_correlation.corr()

# Crea un heatmap della matrice di correlazione
plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f",
            xticklabels=['Test effettuati', 'Nuovi casi positivi', 'Pazienti ospedalizzati', 'Guariti', 'Decessi'], 
            yticklabels=['Test effettuati', 'Nuovi casi positivi', 'Pazienti ospedalizzati', 'Guariti', 'Decessi'])

plt.xticks(rotation=20),
# Impostazioni aggiuntive
plt.title('Correlazione tra Variabili nel Tempo')
plt.show()










